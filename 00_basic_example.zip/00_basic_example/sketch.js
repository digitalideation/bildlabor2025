//1. Load Image

// 8. Load Webcam

// 9. Display Parts of the Webcam (Slit Scan)

function setup() {
  createCanvas(400, 400);

  //6. create a Slider and a Variable to store the value
}

function draw() {
  background(220);

  // 2. Display the image 

  // 3. Copy parts  of the image to the canvas -- use function get() and mouseX, mouseY

  // 4. add some randomness


  // 7. Use the slider value to change the size of the copied part


  
}


// 5. add a save function